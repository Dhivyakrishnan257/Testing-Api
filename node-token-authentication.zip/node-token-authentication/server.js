// =================================================================
// get the packages we need ========================================
// =================================================================
var express 	= require('express');
var app         = express();
var bodyParser  = require('body-parser');
var morgan      = require('morgan');



// =================================================================
// configuration ===================================================
// =================================================================
var port = process.env.PORT || 8080; // used to create, sign, and verify tokens
//var port = process.env.PORT;



// use body parser so we can get info from POST and/or URL parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());



// =================================================================
// routes ==========================================================
// =================================================================

// ---------------------------------------------------------
// get an instance of the router for api routes
// ---------------------------------------------------------



var apiRoutes = express.Router();
var fs = require("fs");
var path=require('path');


// ---------------------------------------------------------
// authenticated routes
// ---------------------------------------------------------

apiRoutes.get('/getData', function(req, res) {

	var fname=req.param('filename');
	//var file=require('./files/'+fname);
	fs.readFile('./files/'+ fname,'utf8',(err, data) => {

	 if (err){
	      res.send("Not found");
				//	res.json(data);
				}
	else{
		res.json(data);
	}
 });
	});


apiRoutes.post('/saveData',function(req, res){
	var color = require('./files/colors');

	var newcolor ={
									colorName:req.body.colorName,
									hexaValue:req.body.hexValue
								};
		color.push(newcolor);
		res.json(color);
		fs.writeFile('./files/colors.json',JSON.stringify(color),'utf8')
		res.json(color);

})


app.use('/api', apiRoutes);

// =================================================================
// start the server ================================================
// =================================================================
app.listen(port);
console.log('Magic happens at http://localhost:' + port);
